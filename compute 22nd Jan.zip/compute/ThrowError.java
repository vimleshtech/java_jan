package compute;

import java.util.Scanner;

public class ThrowError {

	public static void main(String[] args) {

		int n,d,o;
		//create an object of Scanner class
		Scanner sc =new Scanner(System.in);
		
		System.out.println("enter data : ");
		n = sc.nextInt();
				
		System.out.println("enter data : ");
		d = sc.nextInt();
		
		try
		{
			if(d<0)
			{
				Exception ex = new Exception("divisor cannot be less than 0");
				throw ex;
			}
			o =n/d;
			System.out.println(o);
			
		}
		catch (Exception e) {
			System.out.println(e);
		}
	}

}
