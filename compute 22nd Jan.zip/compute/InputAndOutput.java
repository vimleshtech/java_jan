package compute;

import java.net.SocketTimeoutException;
import java.util.Scanner;

public class InputAndOutput {

	public static void main(String[] args) {

		//Scanner  is class , and sc is an object of class Scanner 
		//new is keyword which allocate the memory of class Scanner 
		//System.in : input 
		Scanner sc =new Scanner(System.in);
		
		int n,x,y;
		System.out.println("enter data : ");
		n = sc.nextInt(); //nextInt() is function to read data(numeric) from user 
		
		System.out.println("enter data : ");
		x = sc.nextInt(); //nextInt() is function to read data(numeric) from user 
		
		
		System.out.println("enter data : ");
		y = sc.nextInt(); //nextInt() is function to read data(numeric) from user 
		
		System.out.println("you have entered : "+n);
		
		//show greater no from three inputs
		if(n>x && n>y)
		{
			System.out.println("n is greater");
		}
		else if(x>n && x>y)
		{
			System.out.println("x is greater");
		}
		else
		{
			System.out.println("y is greater");
		}
	}

}
