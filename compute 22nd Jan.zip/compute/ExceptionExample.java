package compute;

public class ExceptionExample {

	public static void main(String[] a)
	{
		int n,d,o;
		n =33;
		d =2;
		
		try
		{
			o = n/d;
			System.out.println(o);
			
			int dd[] = {1,2};
			System.out.println(dd[1]);
			//logout 
		}
		catch (ArithmeticException e) 
		{
			System.out.println(e);
			//logout
		}
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println(e);
			//logout
		}
		catch (Exception z) 
		{
			System.out.println("there is some technical error");
		}
		finally {
			
			System.out.println("end of block");
		}
		
		//
		try
		{
			o = n+d;
			System.out.println("sum of two numbers :"+o);
		}
		finally {
			System.out.println("end of program!!!");
		}
	}
}
