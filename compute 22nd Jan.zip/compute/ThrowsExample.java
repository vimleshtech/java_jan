package compute;

import java.io.FileNotFoundException;
import java.io.FileReader;

public class ThrowsExample {

	public static void main(String[] args) throws FileNotFoundException {

		
		FileReader fr =new FileReader("c:\\abcd\\out.txt");
		
		
		

	}

}
