package example;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
public class crudes {

	public static void main(String[] args) {

		try 
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost/student","root","root");
			
			/*
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("Select * from employee");
			
			while(rs.next()) {
				System.out.print(rs.getString(1));
				System.out.println(rs.getString(2));
			}
			*/
			
			/*String set="CREATE TABLE INSTITUTE" +
						"(id INTEGER," +
						"name VARCHAR(20))";
			st.executeUpdate(set);
			System.out.println("table is created");*/
			
				/*String up="UPDATE employee set eid=? where ename=?";
				PreparedStatement ps= con.prepareStatement(up);		
				ps.setInt(1,4);
				ps.setString(2, "shiv");
				
				ps.executeUpdate();*/
				/*
				String del="DELETE from employee where ename=?";
				PreparedStatement ts= con.prepareStatement(del);		
				ts.setString(1,"shiv");
				ts.executeUpdate();*/
				
				Statement sr=con.createStatement();
				ResultSet s=sr.executeQuery("Select ename from employee where eid=2");
				
				while(s.next())
					System.out.println(s.getString(1));
				
		}
		
		
		catch(Exception e)
		{
			System.out.println(e);
	
		}
	}

}
