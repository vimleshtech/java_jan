package arrayExample;

import java.util.Scanner;

public class TwoDimenssionArrayExample {

	public static void main(String[] args) {
	
		String data[][] = new String[3][2];
		Scanner sc =new Scanner(System.in);
		
		for(int i=0;i<3;i++)
		{
			for(int j=0;j<2;j++)
			{
				System.out.println("enter data : ");
				data[i][j] = sc.nextLine();
				
			}
		}
		
		//show data 
		for(String row[] : data) // [] <- [][] 
		{
			for(String col: row) // data <- row[]
			{
				System.out.print(col+"\t");
			}
			System.out.println();
			
		}
	}

}
