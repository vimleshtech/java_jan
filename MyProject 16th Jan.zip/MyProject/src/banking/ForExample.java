package banking;

public class ForExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int sales[]= {110,230,450,678};
		int sum=0;
		for(int i=0; i<4;i++)
		{
			sum=sum+sales[i];
		}
		System.out.println(sum);
		System.out.println(sum/4);
		
		//
		String s="RAJAT";
		String a="";
		for(int i=0;i<s.length();i++)
		{
			a+=s.charAt(i);
			System.out.println(a);
		}
			
		
			
		
	}

}
