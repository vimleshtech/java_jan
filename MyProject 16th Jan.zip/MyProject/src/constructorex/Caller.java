package constructorex;

public class Caller {

	public static void main(String[] args) {
		
		Calc c =new Calc();
		c.show();
		
		Calc oo =new Calc(c);
		
		new Calc("Nitin");
		
		new Calc(11,2);
		

		c.add(11, 233);
		
	}

}
