package constructorex;

public class Calc {

	int a, b,c,d;
	
	Calc()
	{
		a =1;
		b =33;
		c =0;
		d =44;
		
		System.out.println("welcome to constructor world..");
	}
	Calc(String name)
	{
		System.out.println("name is : "+name);
	}
	Calc(int a, int b)
	{
		System.out.println("sum of num: "+(a+b));
	}
	
	Calc(Calc o)
	{
		System.out.println(o.a);
		System.out.println(o.b);
		System.out.println(o.c);
		System.out.println(o.d);
	}
	void add(int a, int b)
	{
		System.out.println(a+b);
	}
	void show()
	{
		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
		System.out.println(d);
	}
}

