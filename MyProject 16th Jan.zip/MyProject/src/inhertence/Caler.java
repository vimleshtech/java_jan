package inhertence;

public class Caler {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		SavingAccount s =new SavingAccount();
		s.newAccount();
		s.additionalInfo();
		s.show();
		
	}

}
