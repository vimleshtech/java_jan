package inhertence;

public class CurrentAccount extends BankAccount {

	
}
