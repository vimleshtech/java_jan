package inhertence;

import java.util.Scanner;

public class SavingAccount extends BankAccount {

	String adhno;
	String address;
	String gender;
	
	void additionalInfo()
	{
		sc =new Scanner(System.in);
		
		System.out.println("enter adhno   :");
		adhno = sc.nextLine();
		
		System.out.println("enter address  :");
		address= sc.nextLine();
		
		System.out.println("enter gender  :");
		gender =  sc.nextLine();
		
	}
	void show()
	{
		System.out.println("name : "+aname);
		System.out.println("accno : "+accno);
		System.out.println("pan : "+pan);
		System.out.println("amt : "+amt);
		System.out.println("adh : "+adhno);
		System.out.println("add : "+address);
		System.out.println("gender : "+gender);
		
	}
	
	
}
