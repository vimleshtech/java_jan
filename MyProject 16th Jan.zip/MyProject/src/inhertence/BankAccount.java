package inhertence;

import java.util.Scanner;

public class BankAccount {

	public Scanner sc =new Scanner(System.in);
	
	int accno;
	String aname;
	String pan;
	double amt;
	
	void newAccount()
	{
			
		System.out.println("enter name");
		aname= sc.nextLine();
		
		System.out.println("enter acno");
		accno = sc.nextInt();
		
		System.out.println("enter pan");
		pan= sc.next();
		
		System.out.println("enter amt");
		amt= sc.nextInt();
						
	}
	
}
