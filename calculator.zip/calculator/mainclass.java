package calculator;

import java.util.Scanner;

public class mainclass {

	public static void main(String[] args) {
		double g, h, i, j, k;
		
		int m;
		extended e= new extended();
		Scanner sc=new Scanner(System.in);
		
		while(true)
			{
			System.out.println("Enter you choice:");
			System.out.println("1. calculator\n2. interest\n0. Exit ");
			m= sc.nextInt();
			
			if(m==1)
			{ 
				System.out.println("Enter the values");
				g=sc.nextDouble();
				h=sc.nextDouble();

				e.add(g, h);
				e.div(g, h);
				e.sub(g,h);
				e.mul(g, h);
			}
			else if (m==2)
			{ 
				System.out.println("Enter the values");

				i=sc.nextDouble();
				j=sc.nextDouble();
				k=sc.nextDouble();
				e.inter(i, j, k);
			}
			else if (m==0)
			{ 
				System.exit (0);
			}
			
			
			else {
				System.out.println("input invalid hai bhai");
			}
	}

	}
}
