package calculator;

public interface tax {

	void inter(double s, double r, double t);
	

}
