package calculator;

public interface calculator1 { 
	void add (double a, double b);
	void sub(double a, double b);
	void mul(double a, double b);
	void div(double a, double b);
}
