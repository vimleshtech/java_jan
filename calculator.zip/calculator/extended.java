package calculator;

public class extended implements calculator1, tax {

	@Override
	public void inter(double s, double r, double t) {
		double c= (s*r*t)/100;
		System.out.println("interest is:"+ c);
	}

	@Override
	public void add(double a, double b) {
		 double c= a+b;
		System.out.println("sum is :"+ c);
	}

	@Override
	public void sub(double a, double b) {
		double c= a-b;
		System.out.println("difference is:"+ c);
	}

	@Override
	public void mul(double a, double b) {
		double c= a*b;
		System.out.println("product is :"+ c);
	}

	@Override
	public void div(double a, double b) {
		double c= a/b;
		System.out.println("qutiont is:"+ c);
	}

}
