package example;


import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class WriterExample {
	
	public static void main(String[] a) throws IOException
	{
		
		//open or create the file 
		FileWriter o =new FileWriter("C:\\Users\\Tech Vision\\Desktop\\a.txt",true);
		
		//link the buffered(write) physical file
		BufferedWriter bw =new BufferedWriter(o);
		
		//write content to the file
		bw.write("Hi, ");
		bw.newLine();
		bw.write("This my first file which is created from code ");
		bw.newLine();
		bw.write("bye ");
		bw.newLine();
		
		bw.close();
		o.close();
		
		System.out.println("data is saved..");
		
	}

}
