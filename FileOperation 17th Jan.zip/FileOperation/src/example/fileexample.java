package example;



import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class fileexample {
	
public static void main(String[] args) throws IOException {

		int count=0;
		//openthe file
		FileReader f =new FileReader("C:\\Users\\Tech Vision\\Desktop\\a.txt");
		
		BufferedReader b =new BufferedReader(f);		
		
		String line = b.readLine();
		
		while( line !=null)
		{
				//this is java code = {"this","is","java","code"}
				count =count + line.split(" ").length; 
				line = b.readLine();
			
		}
		System.out.println("Total no of words"+count);
		b.close();
		f.close();
 

}
}