package day01;

import java.util.Scanner;

public class Q1 {

	public static void main(String[] args) {
			
		int a,b,c,d,s1,s2,s3,s4,s5,square,cube;
		String name;
		
		Scanner o =new Scanner(System.in);
		
		System.out.println("enter name ");
		name = o.next();
		
		System.out.println("enter data : ");
		a=o.nextInt();
		
		System.out.println("enter data : ");
		b=o.nextInt();
		
		System.out.println("enter data : ");
		c=o.nextInt();
		
		System.out.println("enter data : ");		
		d=o.nextInt();
		
		square=a*a;
		cube=a*a*a;
		
		s1=a*a*a;
		s2=b*b*b;
		s3=c*c*c;
		s4=d*d*d;
		
		s5=s1+s2+s3;
		
		System.out.println("you have entered :"+name);
		if(s5==s4)
			System.out.println("satisfied");
		else
			System.out.println("not satisfied");
		
		System.out.println("square of the number"+square);
		System.out.println("cube of the number"+cube);
}
}