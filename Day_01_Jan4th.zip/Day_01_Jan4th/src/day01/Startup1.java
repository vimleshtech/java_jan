package day01;

public class Startup1 
{
	public static void main(String[] abc) 
	{
	
		//single line comment
		/*
		 * multiple line comment
		 */
		
		//declare variables
		int hs,es,cs,ms;
		int total;
		double avg;
		
		//assign data 
		hs =66;
		es =89;
		ms =90;
		cs =78;
		
		//expression / logic
		total = hs+es+cs+ms;
		avg = total/4;
		
		//show output / print
		//System : class
		//out:inner class
		//println: function 
		System.out.println("total score is "+total);
		System.out.println("average score is "+avg);
				
		
	}
}
