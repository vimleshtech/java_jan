package classExample;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

public class ExcelReader {

	public static void main(String[] args) throws IOException {

		
		FileInputStream fs = new FileInputStream("C:\\Users\\vkumar15\\Desktop\\data.xls");
		
		
		HSSFWorkbook book = new HSSFWorkbook(fs);
		HSSFSheet sheet = book.getSheetAt(2); //get first sheet
		HSSFRow row  = sheet.getRow(0); //get first row
				


		int sc,rc,cc;
		sc = book.getNumberOfSheets();
		rc = sheet.getPhysicalNumberOfRows();

		cc = row.getPhysicalNumberOfCells();
		
		System.out.println("sheet count :"+sc);
		System.out.println("row count :"+rc);
		System.out.println("cell count :"+cc);



		for(int i=0; i<rc;i++)
		{
			row = sheet.getRow(i);
			HSSFCell cell = row.getCell(0);
			System.out.print(cell.getStringCellValue()+"\t");
			cell = row.getCell(1);
			System.out.println(cell.getStringCellValue());
		}
	}

}
