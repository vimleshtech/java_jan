import java.util.Scanner;

public class ArrayClass {


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		/*int a[]=new int[5];//declere array
		
		a[0]=10;
		a[1]=20;
		a[2]=10;
		
		
		int a[]= {10,20,10,10,10};
		int s;
		Scanner sc =new Scanner(System.in);
		System.out.println("enter no to search :");
		s = sc.nextInt();
		
		int c=0;
		
			for(int i=0;i<5;i++)
			{
					if(a[i]==s)
						c++;
				
			}
		
			System.out.println(c);
			*/
		
		int a[]= {10,20,30,9,40,30,45,48,12,34,56,60};
		
		int i,s,average = 0,max=0;
		int min=a[0];
		int total=0;
		
		for(i=0;i<12;i++)
		{
			if(max<a[i])
				max =a[i];
			if(a[i]<min)
				min =a[i];
			total=total+a[i];
			average=total/12;
			
			
		}
		System.out.println(total);
		System.out.println(average);
		System.out.println(max);
		System.out.println(min);
		}
}