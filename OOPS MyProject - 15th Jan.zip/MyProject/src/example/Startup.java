package example;

public class Startup 
{

	public static void main(String[] av) 
	{
		//System : is inbuilt(system defined) class
		//out : is inbuilt class
		//println : is function (method)
		
		System.out.println("Hi");
		System.out.println("Raman");
		
		//print in same line
		System.out.print("Hi ");
		System.out.println("Raman");
		
		//Example 1:
		int a,c;
		a =5;
		c =a*a;
		
		//expression
		System.out.println("square of a number : "+c);
		

	}	

}
