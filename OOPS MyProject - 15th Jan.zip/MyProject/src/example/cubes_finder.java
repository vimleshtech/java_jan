package example;

public class cubes_finder {

	public static void main(String[] args) {
		
		int a,b;
		a = 3;
		b = a*a*a;
		System.out.println("cube of a number is: "+b);

	}

}
