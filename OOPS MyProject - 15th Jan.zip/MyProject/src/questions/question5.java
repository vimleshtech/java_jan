package questions;

import java.util.Scanner;

public class question5 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		int a,b,i;
		double sum=0;
		
		System.out.println("enter first number : ");
		a=sc.nextInt();
		
		System.out.println("enter second number: ");
		b=sc.nextInt();
		
		i=a;
		while(i<=b)
		{
			if(i%2==0 && i%3==0 && i%5!=0)
			{
				sum+=i;
				
				
			}
			i++;
		
		}
		
		System.out.println("sum of numbers is : "+sum);
		
			

	}

}
