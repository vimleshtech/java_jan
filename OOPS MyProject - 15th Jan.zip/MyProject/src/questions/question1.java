package questions;

import java.util.Scanner;

public class question1 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
			int salary=0;
		double hra,da;
		System.out.println("enter the salary of the person : ");
		salary = sc.nextInt();
		if(salary>=5000 && salary<=10000)
		{
			hra=salary*.1;
			da=salary*.05;
			System.out.println("hra of a person is :"+hra);
			System.out.println("DA of a person is :"+da);
			
		}
		else if (salary>=10000 && salary<=15000)
		{
			hra=salary*.15;
			da=salary*.08;
			System.out.println("hra of a person is : "+hra);
			System.out.println("da of a person is : "+da);
			
		}
		else 
		{
			System.out.println("salary is greater than 15000");
			
		}

	}

}
