package questions;

import java.util.Scanner;

public class Question2 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int a,b,c,d,e;
		double percentage;
		System.out.println("enter marks of sub1 : ");
		a= sc.nextInt();
		System.out.println("enter marks of sub2 : ");
		b=sc.nextInt();
		System.out.println("enter marks of sub3 : ");
		c=sc.nextInt();
		System.out.println("enter marks of sub4 : ");
		d=sc.nextInt();
		System.out.println("enter marks of sub5 : ");
		e=sc.nextInt();
		percentage= (a+b+c+d+e)/5;
		System.out.println("percentage is : "+percentage);
		if(percentage>=60)
		{
			System.out.println("You got first division");
		
		}
		else if(percentage>=50 )//percentage>=50 && percentage<=59
		{
			System.out.println("You got second division");
			
		}
		else if(percentage>=40 && percentage<=49)
		{
			System.out.println("you got third division");
		}
		else
		{
			System.out.println("you are fail");
			
		}

	}

}
