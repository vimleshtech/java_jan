package questions;

import java.util.Scanner;

public class Quetion3 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int a;
		double b;
		
		System.out.println("unit : " );
		a= sc.nextInt();
		
		if(a>=100)
		{
			b=a*.40;
			
		}
		else if(a>=100 && a<=300)
		{
			
			b= 40+ (a-100)*.50;
			
			
		}
		else//a>=300 && a<=600);
		{
			b= 140+ (a-300)*.60;
			
			
		}
		b=b+50;
		
		System.out.println("total :"+b);

	}

}
