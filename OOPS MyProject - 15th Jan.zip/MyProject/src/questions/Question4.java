package questions;

import java.util.Scanner;

public class Question4 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n,i;
		double sum=0,average=0;
		System.out.println("Enter Number : ");
		n= sc.nextInt();
		for(i=1;i<=n;i++)
		{
			sum+=i;
			average=sum/n;
			
		}
		System.out.println("sum of number is : "+sum);
		System.out.println("average of number is : "+average);
		

	}

}
