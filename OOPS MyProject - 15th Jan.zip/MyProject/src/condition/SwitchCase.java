package condition;

import java.util.Scanner;

public class SwitchCase {

	public static void main(String[] args) 
	{
		
		Scanner sc =new Scanner(System.in);
		int choice,a,b;
		System.out.println("press 1 for add 2 for sub 3 for sub ");
		choice = sc.nextInt();
				
		
		System.out.println("enter data  ");
		a = sc.nextInt();
		
		
		System.out.println("enter data ");
		b= sc.nextInt();
		
		switch(choice)
		{
		
			case 1:
					System.out.println(a+b);
					break; //terminate the block 
			case 2:
				System.out.println(a-b);
				break;
			case 3:
				System.out.println(a*b);
				break;
			default:
				System.out.println("invalid input");
				break;
			
		}
		
	}

}
