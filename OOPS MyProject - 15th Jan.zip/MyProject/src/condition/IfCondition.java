package condition;

import java.util.Scanner;

public class IfCondition {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc =new Scanner(System.in);
		int sales=0;
		double tax=0;
		
		
		System.out.println("enter sale amount: ");
		sales =sc.nextInt();//nextInt() is function to read number value from user/console 
		
		
		//if condition without else 
		if(sales>1000) 
		{
			tax = sales*.18;
		}
		tax = sales+tax;
		System.out.println("total amount : "+tax);
		
		//if else condition 
		if(sales>1000) 
		{
			tax = sales*.18;
		}
		else 
		{	
			tax = sales*.05;
		}
		tax = sales+tax;
		System.out.println("total amount : "+tax);
		
		//if else if else ...else / ladder if else 
		if(sales>1000) 
		{
			tax = sales*.18;
		}
		else if(sales>500)
		{	
			tax = sales*.10;
		}
		else
		{
			tax = sales*.05;
		}
		
		tax = sales+tax;
		System.out.println("total amount : "+tax);
		
		//nested if else 
		//wap to take three numbere from user and show greater no
		int a,b,c;
		System.out.println("enter number : ");
		a = sc.nextInt();
		
		System.out.println("enter number : ");
		b = sc.nextInt();
		
		System.out.println("enter number : ");
		c = sc.nextInt();
		
		if(a>b)
		{
			if(a>c)
			{
				System.out.println(" a is greater ");
			}
			else
			{
				System.out.println(" b is greater ");
			}
		}
		else
		{
			if(b>c)
			{
				System.out.println("b is greater");
			}
			else
			{
				System.out.println("c is greater");
			}
		}
			
		
		//if else with and condition 
		if(a>b && a>c)
		{
			System.out.println("a is greater ");
		}
		else if(b>a && b>c)
		{
			System.out.println("b is greater");
		}
		else
		{
			System.out.println("c is greater");
		}
		
	}

}
