package loop;

import java.util.Scanner;

public class ForLoop {

	int add() {
		int a=10;
		int b=20;
		int c=a+b;
		System.out.println(c);
		return 0;
	}
	
	
	public static void main(String[] args) {
		
	/*	for(int i=1; i<10; i++)
		{	
			System.out.println(i);
		}
		
		//wap to print table of given no.
		int t=0;
		Scanner sc =new Scanner(System.in);
		
		System.out.println("enter number : ");
		t = sc.nextInt();
		
		for(int i=1; i<=10;i++)
		{
			System.out.println(t*i);
		}
		
		===================================
		int i,a=0;
		for( i=1;i<=10;i++)
		{
			a+=i;
			System.out.println(a);
		}
		System.out.println(a);
		
		
		
		/*for(int i=1;i<8;i++)
		{    
			System.out.print("(");
			for(int j=1;j<=i;j++)
			{
				if(j<i)
					System.out.print(j+"+");
				else
					System.out.print(j);
			}
			System.out.print(")+");
		}
		
	}

}

		for(int i=1;i<=10;i+=2)			
		{
			
						System.out.print("(");
						
						for(int j=1;j<=i;j+=2)
						{
							if(j<i)
							
								System.out.print(j+"+");
							else
								System.out.print(j);
							
							
							
						}
						System.out.print(")");
						
			
			}
		*/
		
	}

}

