package oops;

public class Caller {

	public static void main(String[] args) {
		
		//Class  Object allocate_memory call_to_constructor
	
		Employee e1 =   new 			Employee();
		e1.newemp();
		//e1.eid =11;
		
		/*
		Employee e2 =new Employee();
		e2.newemp();
		
		e2.compute();
		e1.compute();
		
		e2.info();
		e1.info();
		*/
		//array of objects
		Employee o[] = new Employee[4];
		
		for(int i =0; i<4;i++)
		{
			o[i] =new Employee();
			o[i].newemp();
			o[i].compute();
		}
		
		for(Employee ee : o)
			ee.info();
	}

}
