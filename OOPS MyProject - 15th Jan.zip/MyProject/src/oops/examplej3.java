package oops;

import java.util.Scanner;

public class examplej3 {

		// TODO Auto-generated method stub
     private int pan;
     private String name;
     private float income;
     private float tax;


 	public static void main(String[] args) {
		
		
		
	}
 	void input()
 	{
 		Scanner sc= new Scanner(System.in);
 		System.out.println("enter the pan ");
 		pan =sc.nextInt();
      
 		System.out.println("enter the name ");
 		name = sc.next();
        System.out.println("Enter the income ");
        income= sc.nextFloat();
    
      }
 	void calc()
 	{
 		if(income>500000)
 			tax=0.20f*income;
 		else if(income<500000 && income>200000)
 			tax=0.15f*income;
 		else if(income<200000 && income>100000)
           tax=0.10f*income;
 		else
 			tax=0;
 	}	
 		
 	void display()
 	{
 		System.out.println(" the pan "+pan);
 		System.out.println(" the name "+name);
 		System.out.println(" the income "+income);
 		System.out.println(" the tax "+tax);
 	}

}
