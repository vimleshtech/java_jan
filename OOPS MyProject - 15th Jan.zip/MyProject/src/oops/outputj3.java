package oops;

public class outputj3 {

	public static void main(String[] args) {
		
	/*examplej3 o = new examplej3();
		o.input();
		o.calc();
		o.display();
*/
		studentj5 o[]=new studentj5[10];
		for(int i=0; i<10;i++)
		{
			o[i] =new studentj5();			
			o[i].input();		
		}
		
		for(int i=0; i<10;i++)
		{
			for(int j=i+1; j<10;j++)
			{
					if(o[i].Retroll()>o[j].Retroll())
					{
						studentj5 temp = o[i];
						o[i] =o[j];
						o[j] =temp;
					}
			}		
		}
		
		for(studentj5 t : o)
			t.display();
		
		
	}

}
