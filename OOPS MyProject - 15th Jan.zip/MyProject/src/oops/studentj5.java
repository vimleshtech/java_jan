package oops;

import java.util.Scanner;

public class studentj5 {

	  private int roll;
	     private String name;
	     private String address;	
	     private String city;			
	     private String country;
	     
	     
	     
	     public void input()
	     {
	    	 Scanner sc = new Scanner(System.in);
	    	 roll=sc.nextInt();
	    	 name=sc.next();
	    	 address=sc.next();
	    	 city=sc.next();
	    	 country=sc.next();
	    	 
	     }
	     
	     public void display()
	     {
	    	 System.out.println(roll);
	    	 System.out.println(name);
	    	 System.out.println(address);
	    	 System.out.println(city);
	    	 System.out.println(country);
	    	 
	     }
	     	public int Retroll()
	     	{
	     		return roll;
	     		
	     		
	     	}
	    
}
