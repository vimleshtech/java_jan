package oops;

import java.util.Scanner;

public class Employee {

	//data member
	private	int eid;
	private String ename;
	private int sal;
	private double msal,ysal;
	
	
	//method 
	protected void newemp()
	{
		Scanner sc =new Scanner(System.in);
		
		System.out.println("enter eid : ");
		eid = sc.nextInt();
		
		System.out.println("enter name : ");
		ename = sc.next();
		
		
		System.out.println("enter sal : ");
		sal = sc.nextInt();
		
	}
	void compute()
	{
		msal = sal*.40+ sal*.20+sal;
		ysal = msal*12;
		
		
	}
	void info()
	{
		System.out.println("--Employee Details--");
		System.out.println("Emp id : "+eid);
		System.out.println("Emp name : "+ename);
		System.out.println("Emp msal : "+msal);
		System.out.println("Emp ysal : "+ysal);
		
	}
}
