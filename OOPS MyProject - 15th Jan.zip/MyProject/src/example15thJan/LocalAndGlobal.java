package example15thJan;

public class LocalAndGlobal 
{

	//global 
	static int x;
	public static void main(String[] args) 
	{
		
		//local variable : can be access within class 
		int a=11;
		
		
		//
		x =11;

	}
	
	static void test()
	{
		System.out.println(x);
		
	}

}
class test
{
	
}