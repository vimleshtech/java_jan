package loop;

public class AdvanceLoop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int n[] = {111,222,333,4};
		
		//for a in n
		for(int a:n)
		{
			System.out.println(a);
		}
		
	}

}
