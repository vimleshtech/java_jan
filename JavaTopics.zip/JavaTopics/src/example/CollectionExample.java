package example;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class CollectionExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		
		ArrayList al = new ArrayList();
		al.add(11);
		al.add(141);
		al.add(191);
		al.add("raman");
		
		al.add(1100);
		al.add(17771);
		al.add(1661);
		al.add(true);
		
		System.out.println(al.size());
		
		al.remove(2);
		System.out.println(al.size());
		
		System.out.println(al.get(2));
		
		
		for(int i=0; i<al.size();i++)
			System.out.println(al.get(i));
		
		
		///list
		List l =new ArrayList();
		l.add(11);
		l.add("nitin");
		System.out.println(l.size());
		System.out.println(l.get(1));
		
		//HasMap 
		HashMap m = new HashMap();
		m.put("m", "monday");
		m.put(1, "one");
		
		System.out.println(m.get("m"));
		

	}

}
