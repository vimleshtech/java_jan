package example;

import java.util.ArrayList;

public class GenericExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ArrayList<Integer> a =new ArrayList<>();
		
		a.add(11);
		//a.add("sjsgh");
		a.add(131);
		a.add(141);
		a.add(151);
		
		System.out.println(a.size());
		
		//
		ArrayList<String> s= new ArrayList<>();
		s.add("fhhf");
		s.add("fhhf");
		s.add("fhhf");
		s.add("fhhf");
		s.add("fhhf");
		s.add("1");
	}

}
