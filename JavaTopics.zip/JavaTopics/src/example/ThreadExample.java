package example;

public class ThreadExample {

	public static void main(String[] args) throws InterruptedException {
	
		Thread t = Thread.currentThread();
		System.out.println(t);
		//Thread priority 5 -1 High to low 
		t.setName("My Process");
		System.out.println(t);
		
		NewThread nn =new NewThread("New Thread");
		
		for(int i=0;i<5;i++)
		{
			System.out.println("My Proess :"+i);
			Thread.sleep(1000);
			
		}

	}

}

class NewThread implements Runnable
{
	Thread nt=null;
	NewThread(String name)
	{
		nt=new Thread(this,name);
		nt.start();
		
	}
	@Override
	public void run() {
		
		for(int i=0;i<5;i++)
		{
			System.out.println("thread 2 :"+i);
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
	}
	
	
}
