package collection.example;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class CollectionExample {

	
	public static void main(String[] a)
	{
		
		ArrayList al = new ArrayList();
		al.add(11);
		al.add(true);
		al.add("ji");
		al.add(11.444);
		al.add(1000);

		System.out.println(al.size());
		
		al.remove(3);
		System.out.println(al.size());
		
		
		for(int i=0; i<al.size();i++)
		{
			System.out.println(al.get(i));
		}
		
		//List
		List l = new ArrayList();
		l.add(21);
		l.add(44);
		l.add("fksfgsh");
		
		System.out.println(l.size());
		
		
		//HashMap
		HashMap map = new HashMap();
		map.put("a", "alpha");
		map.put("b", "beata");
		map.put("c", "ceta");
		map.put("d", "delta");
		map.put(1,"one");
		
		
		System.out.println(map.get(1));
		System.out.println(map.get("c"));
		
		
	}
}
