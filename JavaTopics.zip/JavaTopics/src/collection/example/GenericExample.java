package collection.example;

import java.util.ArrayList;

class employee{
	
	int eid;
	String name;
	int sal;
	
	employee(int eid, String name, int sal){
		
		this.eid = eid;
		this.name = name;
		this.sal  = sal;		
	}
	
	
}
public class GenericExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		ArrayList<String> a = new ArrayList<>();
		
		//a.add(11);
		a.add("sjgs");
		
		//
		ArrayList<employee> e = new ArrayList<>();
		e.add(new employee(11, "raman", 3333));
		e.add(new employee(1, "raman", 3333));
		e.add(new employee(311, "raman", 3333));
		e.add(new employee(411, "raman", 3333));
		e.add(new employee(511, "raman", 3333));
		e.add(new employee(611, "raman", 3333));
		e.add(new employee(711, "raman", 3333));
		
		System.out.println(e.size());
		
		for(int i=0; i<e.size();i++)
		{
			System.out.println(e.get(i).eid+"\t"+e.get(i).name);
		}
		
		
	}

}
