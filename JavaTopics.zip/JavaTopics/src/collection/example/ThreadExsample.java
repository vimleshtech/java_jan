package collection.example;

public class ThreadExsample {

	public static void main(String[] args) throws InterruptedException {
		
		Thread t = Thread.currentThread();
		System.out.println(t);
		
		t.setName("new name");		
		System.out.println(t);
		
		newThread tt = new newThread("thread-2");
		
		
		for(int i=0; i<5;i++)
		{
			System.out.println(i);			
			Thread.sleep(500); //5 sec 
		}
		

	}

}


class newThread implements Runnable {
	

	Thread nt=null;
	newThread(String name){
		
		nt =new Thread(this,name);
		nt.start();
		
	}
	
	public void run() {
		for(int i=10; i<15; i++) {
			System.out.println("new process :"+i);
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}