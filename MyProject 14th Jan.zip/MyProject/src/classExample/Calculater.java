package classExample;

public class Calculater {

	/*static void add(int a, int b)
	{
		System.out.println(a+b);
	}
	static void sub(int a, int b)
	{
		System.out.println(a-b);
	}
	static void mul(int a, int b)
	{
		System.out.println(a*b);
	}
	
	static void div(int a, int b)
	{
		System.out.println(a/b);
	}*/
	static int square(int a)
	{
		int c=a*a;
		return c;
	}
	
	
}
