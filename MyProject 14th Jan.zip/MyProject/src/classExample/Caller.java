package classExample;

public class Caller {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//Calculater.add(11,3);
		//Calculater.sub(11,3);
		//Calculater.mul(11,3);
		//Calculater.add(110,30);
		//Calculater.div(11,3);
//	int a=	Calculater.square(2);
		System.out.println(Calculater.square(2));
	}

}

class test{
	
	
}