package classExample;
import java.util.Scanner;
public class Array2D {

	public static void main(String[] args) {
		
		String data[][] = new String[3][3];
		
		Scanner arr= new Scanner(System.in);
		
		for(int i=0;i<3;i++)
		{
			for(int j=0;j<3;j++)
			{
				
				System.out.println("Enter the values in 2d");
				data[i][j]=arr.nextLine();
			}
		}
		
		String dd[][] = {{"","",""},{"","",""},{"","",""}};
		
		///
		for(int i=0;i<3;i++)
		{
			for(int j=0;j<3;j++)
			{				
				System.out.print(data[i][j]+"\t");
			
			}
			System.out.println();
		}
		
		
	}

}
