package example;

import java.util.Scanner;


public class InputAndOutput {

	public static void main(String[] args) 
	{

		/*
		Scanner s = new Scanner(System.in); 
		
		String name;
		int id;
		int sal;
		int totalsal;
		
		System.out.println("Enter Name  ");
		name = s.nextLine();
		
		System.out.println("Enter id  ");
		id= s.nextInt();
		
		System.out.println("Enter sal  ");
		sal = s.nextInt();
		
		
		//expression 
		totalsal = sal*12;
		
		System.out.println("----User Details ----- ");
		System.out.println("Name : "+name);
		System.out.println("Total Sal : "+totalsal);
		
		*/
		
		welcome();
		
		int o1 = getInput();
		int o2 = getInput();		
		System.out.println(o1);
		
		add(o1,o2);
		
		int o  = sub(o1,o2);
		System.out.println(o);
		

	}
	
	//no argument no return 
	static void welcome()
	{
			System.out.println("welcome to function world.");
			System.out.println("This class contains following functions: \n 1. Welcome() \n 2. AddUser() \n 3 ShowUser() \n 4. Compute() .");
			
			
	}
	
	//no argument with return 
	static int getInput()
	{
		Scanner sc = new Scanner(System.in);
		int data;
		System.out.println("enter data : ");
		data = sc.nextInt();
		
		return data;
	}

	//argument with no return 
	static void add(int a, int b)
	{
		int c =a+b;
		System.out.println(c);
	}
	
	//argument with return 
	static int sub(int x, int y)
	{
		return x-y;
	}
	
}
