package snippet;

import java.util.Random;

public class RandomExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Random r = new Random();
		int low = 100;
		int high = 200;
		for(int i=0;i<20;i++)
		{
		int result = r.nextInt(high-low) + low;
		
		System.out.println(result);
		}
	}

}
