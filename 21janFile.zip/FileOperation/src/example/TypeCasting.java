package example;

public class TypeCasting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		/*
		 * Type Casting
		 * -Implicit 
		 * -Explicit 
		 */
		
		//Implicit
		int n=1;
		long l =44;
		
		l = n; //implicit 
		
		n =(int) l; //explicit 
		//or
		String ss ="1122";
		n = Integer.parseInt(ss);
		
		System.out.println(n+1);
		
		
		

	}

}
