package example;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Combination {

	public static void main(String[] args) throws IOException {
		String comb = "abc";

		//open the file from physical location 
		FileWriter fw =new FileWriter("C:\\Users\\Tech Vision\\Desktop\\comb.txt");
		FileReader fr =new FileReader("C:\\Users\\Tech Vision\\Desktop\\comb.txt");

		//read content from file 
		BufferedWriter bw =new BufferedWriter(fw);
		BufferedReader br =new BufferedReader(fr);

		//process/iterate the data 
		String line = br.readLine(); //read first line from the file 		
		for(int i=0;i<comb.length();i++)
		{
			String ch[]=comb.split("");
			System.out.print(ch[i]);
			
					for(int p=0;p<3;p++)
					{
						if(ch[i]!=ch[p])	
						System.out.print(ch[p]);
					
					}System.out.println();
					System.out.print(ch[i]);
					
					for(int p=2;p>=0;p--)
					{
						if(ch[i]!=ch[p])	
						System.out.print(ch[p]);
					
					}
					
					
					
					System.out.println();	
					
					
		}
	
		fw.close();
		bw.close();
		
				
	}

		

	}


