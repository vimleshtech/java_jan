package example;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class BreakData {

	public static void main(String[] args) throws IOException {
		
		//open the file from physical location 
		FileReader fr =new FileReader("C:\\Users\\Tech Vision\\Desktop\\emp.txt");

		//read content from file 
		BufferedReader br =new BufferedReader(fr);

		//process/iterate the data 
		String line = br.readLine(); //read first line from the file 		
		int i=0;
		
		/// create file for male employee
		//open the file from physical location 
		FileWriter fw1 =new FileWriter("C:\\Users\\Tech Vision\\Desktop\\male.txt");
		BufferedWriter bw1 =new BufferedWriter(fw1);
						
		/// create file for female employee
		FileWriter fw2 =new FileWriter("C:\\Users\\Tech Vision\\Desktop\\female.txt");
		BufferedWriter bw2 =new BufferedWriter(fw2);
				
		
		while(line !=null)
		{
		
			if(i>0) //ignore first or header row 
			{
				//System.out.println(line);
				String col[] = line.split(","); //{"id","name","gender","salary" }
				//System.out.println(col[1]);
			
				if(col[2].equals("male"))
				{
					bw1.write(line);
					bw1.newLine();
				}
				else
				{
					bw2.write(line);
					bw2.newLine();
				}	
			}
			
			line  = br.readLine();			
			i++;
		}
		
		
		bw1.close();
		bw2.close();
		fw1.close();
		fw2.close();
		
	}

}
