package example;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class ReaderExample {

	public static void main(String[] args) throws IOException {
		
		//open the file from physical location 
		FileReader fr =new FileReader("C:\\Users\\Tech Vision\\Desktop\\emp.txt");

		//read content from file 
		BufferedReader br =new BufferedReader(fr);

		//process/iterate the data 
		String line = br.readLine(); //read first line from the file 
		int sum_male = 0, sum_female =0;
		int i=0;
		
		while(line !=null)
		{
		
			if(i>0) //ignore first or header row 
			{
				//System.out.println(line);
				String col[] = line.split(","); //{"id","name","gender","salary" }
				//System.out.println(col[1]);
			
				if(col[2].equals("male"))
					sum_male = sum_male + Integer.parseInt( col[3]);
				else
					sum_female = sum_female + Integer.parseInt( col[3]);
					
			}
			
			line  = br.readLine();			
			i++;
		}
		System.out.println("sum of salary of all male emloyees : "+sum_male);
		System.out.println("sum of salary of all female employees :"+sum_female);

	}

}
