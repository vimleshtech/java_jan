package arrayExample;

import java.util.Scanner;

public class ArrayWithInput {

	public static void main(String[] args) {
		
		Scanner sc =new Scanner(System.in);
		int size;
		
		System.out.println("enter size of array :");
		size = sc.nextInt();
		
		int arr[] =new int[size];
		
		for(int ind=0;ind<size;ind++)
		{
			System.out.println("enter data : ");
			arr[ind] = sc.nextInt();
		}

		//get max value 
		int max =arr[0];
		int mind = 0;
		
		for(int j=0; j<arr.length;j++)
		{
			if(max<arr[j])
			{
				max = arr[j];
				mind  = j;
			}
		}
		System.out.println("Highest value at position  "+mind+" is : "+max);
		//get lowest/value 
		int min=arr[0]; 
		for(int j=0; j<arr.length;j++)
		{
			if(min>arr[j])
				min = arr[j];
		}
		System.out.println("Lowest value is :"+min);		
		
		
		//get count of given no 
		int nno,counter=0;
		System.out.println("enter new to search : ");
		nno = sc.nextInt();
		for(int j=0; j<arr.length;j++)
		{
			if(nno == arr[j])
				counter++;
		}
		
		System.out.println("count of "+nno+" is : "+counter);
		//show data 
		System.out.println("...Print data in same order...");
		for(int j=0; j<arr.length;j++)
		{
			System.out.println(arr[j]);
		}
		
		System.out.println("...Print data in reverse order...");
		for(int j=arr.length-1; j>=0;j--)
		{
			System.out.println(arr[j]);
		}
	}

}
