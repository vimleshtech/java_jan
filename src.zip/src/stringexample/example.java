package stringexample;
import java.util.Scanner;
public class example {

	public static void main(String[] args) {
	
	String str,nstr,stg;
	char a;
	Scanner st= new Scanner(System.in);
	System.out.println("Enter the string");
	str=st.nextLine();
	stg=st.nextLine();
	//a=st.next();
	/*int count=0;
	if(str.equals(" "));
	count++;
	System.out.println(count);*/
			
/*if(str.equals("char"))
	nstr = str.toUpperCase();
	System.out.println(nstr);

	nstr = str.toLowerCase();
	System.out.println(nstr); */
	int ps = str.indexOf("v");
	System.out.println(ps);
	
	if(str==stg)
	System.out.println(str);
	//else
	//	System.out.println(0);
	
	}

}
