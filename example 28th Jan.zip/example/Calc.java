package example;

public class Calc extends Compute {

	void add(int a, int b , int c)
	{
		System.out.println("sum of three nos.:"+(a+b+c));
		
	}
	
	void welcome()
	{
		System.out.println("child class");
	}
	
}
