package example;

public class Compute {
	
	void welcome() {
		
		System.out.println("Parent Class");
	}

	void add(int a, int b) {
		
		System.out.println(a+b);
	}
	void add(double a, double b) {
		
		System.out.println("sum of double :"+a+b);
	}
	
}
