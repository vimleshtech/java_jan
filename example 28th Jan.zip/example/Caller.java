package example;

public class Caller {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		Calc c =new Calc();
		//call to overloaded function 
		c.add(11, 2);
		c.add(11.22, 2);
		c.add(11.33, 2.33);
		c.add(11, 2,11);
		
		
		///
		Compute co =new Compute();
		co.welcome();
		c.welcome();
				
		//overriding
		co = c;
		co.welcome(); //child 
		
		//or 
		Compute cc =new Calc();
		
		cc.welcome(); //child 
		

		////
		call_to_fun(new Compute());
		call_to_fun(new Calc());
		
	}
	
	static void call_to_fun(Compute c) {
		
		c.welcome();
		c.add(11, 22);
		
	}

}
