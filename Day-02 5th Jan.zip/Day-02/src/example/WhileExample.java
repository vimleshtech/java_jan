package example;

public class WhileExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int i=1;
		while(i<=100)
		{
			//System.out.println(i);
			System.out.print(i);
			i++; //i=i+1
		}
		
		//print in reverse
		i=100;
		while(i>=1)
		{
			//System.out.println(i);
			System.out.print(i);
			i--; 
		}
		
		
		//wap to get sum or all even and odd numbers
		System.out.println();
		int se=0,so=0;
		i=1;
		while(i<=100)
		{
			if(i%2==0)
			{
				se +=i;
			}
			else
			{
				so +=i;
			}
			i++;
		}
		
		System.out.println(se);
		System.out.println(so);
		
		//wap to show all odd numbers between 1 to 30
		i =1;
		while(i<=30)
		{
			System.out.println(i);
			i=i+2;
			
		}
	}

}
