package example;

public class series01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(int i=2;i<10;i=i+2)
		{
			System.out.print("(");
			for(int j=2;j<=i;j=j+2)
			{
			if(j<i)
			System.out.print(j+"+");
			else
					System.out.print(j);
				
			}
			System.out.print(")+");
		
		}

	}

}
