package example;

public class series {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	int sum=1;
	System.out.print(sum);
	  
     for(int i=1;i<10;i++)
     {
      sum=2*i;
      System.out.print(sum+",");
     }
	}

}
