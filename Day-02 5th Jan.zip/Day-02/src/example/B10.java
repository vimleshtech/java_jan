package example;

import java.util.Scanner;

public class B10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner s =new Scanner(System.in);
		int unit;
		double amt=0;
		
		System.out.println("enter unit :");//message
		unit= s.nextInt(); //read int number
		
		if(unit<=100)
		{
			amt = unit*.40;
		}
		else if(unit <=300)
		{
			amt = 40 +(unit-100)*.50;
		}
		else 
		{
			amt = 140 +(unit-300)*.60;
		}
		
		amt =amt+50; //amt =amt+50
		System.out.println(amt);
		
		
		
		
	}

}
