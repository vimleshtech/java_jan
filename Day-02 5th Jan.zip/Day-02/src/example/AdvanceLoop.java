package example;

public class AdvanceLoop {

	public static void main(String[] args) {
		
		int n[] = {111,22,3,22,1,32};
		
		//foreach //read all elements one by one
		//forward only
		for(int d: n)
		{
			System.out.println(d);
		}

	}

}
